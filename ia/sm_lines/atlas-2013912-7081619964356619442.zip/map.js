{
	"template":"Single Map (HTML Edition)",
	"version":"6.7.1_b1,635 (2013-09-04 1449)",
	"boundingBox":"-459125.45 7460378.96 -257277.67 7624542.95",
	"layers":[
	{
		"type":"base-layer",
		"id":"_Roads_Edinburgh.shp1",
		"name":"Roads",
		"geometry":"line",
		"url":"_Roads_Edinburgh.shp1.js",
		"visible":true,
		"symbolSize":15,
		"fillColor":"#ffffff",
		"fillOpacity":0.8,
		"borderColor":"#cccccc",
		"borderThickness":2,
		"showLabels":false,
		"minLabelExtent":0,
		"maxLabelExtent":1000000,
		"iconPath":"",
		"showDataTips":true,
		"showInLayerList":true
	},
	{
		"type":"google-layer",
		"id":"ds934b82b7-6ce7-4075-879b-b0890abaa259",
		"geometry":"image",
		"apiKey":"",
		"mapType":"physical"
	}
	]
}