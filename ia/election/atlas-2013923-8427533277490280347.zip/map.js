{
	"template":"Election Results (HTML Edition)",
	"version":"6.7.1_b1,595 (2013-09-04 1449)",
	"boundingBox":"-216638.09399999998 6569393.0895 -192517.646 6583186.8805",
	"layers":[
	{
		"type":"base-layer",
		"id":"_Wards_Bournemouth.shp1",
		"name":"Wards",
		"geometry":"polygon",
		"url":"_Wards_Bournemouth.shp1.js",
		"visible":true,
		"symbolSize":15,
		"fillColor":"#ffffff",
		"fillOpacity":0.8,
		"borderColor":"#cccccc",
		"borderThickness":1,
		"showLabels":false,
		"minLabelExtent":0,
		"maxLabelExtent":1000000,
		"iconPath":"",
		"showDataTips":true,
		"showInLayerList":true
	},
	{
		"type":"ags-layer",
		"id":"wms135046995",
		"name":"World Street Map",
		"geometry":"image",
		"visible":true,
		"url":"http://server.arcgisonline.com/ArcGIS/rest/services/World_Street_Map/MapServer/export?",
		"layers":"0",
		"srs":"102100",
		"params":"",
		"showInLayerList":true
	}
	]
}